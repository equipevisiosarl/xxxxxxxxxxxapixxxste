<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Rendez_vousController extends Controller
{
    //
}
